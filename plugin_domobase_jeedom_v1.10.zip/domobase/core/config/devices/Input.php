<?php

/* This file is part of Jeedom.
 *
 * Jeedom is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Jeedom is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Jeedom. If not, see <http://www.gnu.org/licenses/>.
 */

global $deviceConfiguration;
$deviceConfiguration = array(
    'Input' => array(
        'name' => 'Entrée numeriques',
        'isVisible' => 1,
        'isEnable' => 1,
        'category' => array('automatism' => '1'),
        'commands' => array(
            array('name' => 'Lecture', 'type' => 'action', 'subtype' => 'other', 'isVisible' => 1, 'isHistorized' => 0, 'unite' => '', 'eventOnly' => 0,
                'logicalId' => '$INPUTS',
                'value' => 'Etat',
                //'template' => '{"dashboard":"lightIMG","mobile":"light"}',
                                'configuration' => array(
                    'deltaAdresse' => '07'
                )
            ),
            array('name' => 'Etat', 'type' => 'info', 'subtype' => 'binary', 'isVisible' => 1, 'isHistorized' => 0, 'unite' => '', 'eventOnly' => 1,
                'logicalId' => '#INPUTS',
                //'template' => '{"dashboard":"alert","mobile":"alert"}',
				'configuration' => array(
                    'deltaAdresse' => ''
                )
            )
        )
    )
);
?>
