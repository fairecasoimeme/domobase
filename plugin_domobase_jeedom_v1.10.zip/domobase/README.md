Plugin de communication RS232 Jeddom pour carte DOMOBASE HomeMade.
32 Entrées analogiques/numériques.
32 Sorties Numériques.
12 Sorties RELAIS.
8 Entrées Compteur impulsions.
1 Port RS232.
1 Port RS485.